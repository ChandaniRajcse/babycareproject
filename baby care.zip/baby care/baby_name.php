<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/style1.css">
    <style>
        body, html {
            height: 100%;
            font-family: Arial, Helvetica, sans-serif;
        }
        * {
            box-sizing: border-box;
        }
        .bg-img {
            background-image: url("image/baby2.jpg");
            min-height: 600px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            position: relative;
        }
        .container {
            position: absolute;
            right: 0;
            margin: 20px;
            max-width: 300px;
            padding: 16px;
            background-color: white;
        }
        input[type=text], input[type=password] {
            width: 100%;
            padding: 15px;
            margin: 5px 0 22px 0;
            border: none;
            background: #f1f1f1;
        }
        input[type=text]:focus, input[type=password]:focus {
            background-color: #ddd;
            outline: none;
        }
        .btnn {
            background-color: #04AA6D;
            color: white;
            padding: 16px 20px;
            border: none;
            cursor: pointer;
            width: 100%;
            opacity: 0.9;
        }
        .btnn:hover {
            opacity: 1;
        }
    </style>
</head>
<body>
    <nav class="navbar">
       
        <a href="Home.html">Home</a>
        <a href="baby_name.html">Baby name</a>
        <a href="tips.html">Tips</a>
        <a href="food.html">Food</a>
        <a href="product.html">Product</a>
     
        
    </nav>

    <div class="bg-img">
        <form method="post" class="container">
            <h1>Add Baby Name</h1>

            <label for="Name"><b>Name</b></label>
            <input type="text" placeholder="Enter Name" name="name" required>

            <label for="Meaning"><b>Meaning</b></label>
            <input type="text" placeholder="Enter name meaning" name="meaning" required>

            <label for="sex1">Sex:</label>
            <input type="radio" name="sex" value="boy" id="sex1"/>Boy
            <input type="radio" name="sex" value="girl" id="sex1"/>Girl<br><br>

            <label for="religion1">Religion:</label>
            <select name="religion">
                <option>Hindu</option>
                <option>Muslim</option>
                <option>Christian</option>
                <option>Sikh</option>
                <option>Jews</option>
                <option>Jain</option>
                <option>Buddhist</option>
            </select><br><br>

            <button type="submit" class="btnn" name="Add">Add Baby Name</button>
        </form>
    </div>

    <?php
    // PHP code for database insertion
    if (isset($_POST['Add'])) {
        $add_baby_name = $_POST['name'];
        $meaning_name = $_POST['meaning'];
        $gender = $_POST['sex'];
        $religion = $_POST['religion']; // Corrected the variable name to 'religion'
    
        // Database connection
        $conn = new mysqli('localhost', 'root', '', 'babycare');
    
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
    
        // Insert data
        $stmt = $conn->prepare("INSERT INTO baby (baby_name, meaning_name, Gender, Relgion) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $add_baby_name, $meaning_name, $gender, $religion); // Make sure 'religion' matches the form field
    
        if ($stmt->execute()) {
            // Redirect to the same page with a success message
            header("Location: " . $_SERVER['PHP_SELF'] . "?success=1");
            exit(); // Make sure to call exit after a redirect
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }
    
        $stmt->close();
        $conn->close();
    }
    
    // Check for success parameter in the URL
    if (isset($_GET['success'])) {
        echo "<script>alert('New record created successfully');</script>";
    }
    ?>
    
</body>
</html>
